a = int(input("Escriba el primer numero: "))
b = int(input("Escriba el segundo numero: "))
if a>=b:
  print("El numero mayor es",a)
else: 
  print ("El numero mayor es",b)
