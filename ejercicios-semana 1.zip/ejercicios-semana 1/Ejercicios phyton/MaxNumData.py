a=5
b=20
if a>=b:
  print("El numero mayor es",a)
else: 
  print ("El numero mayor es",b)





 