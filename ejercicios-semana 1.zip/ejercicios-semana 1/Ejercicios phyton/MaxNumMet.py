def MaxNum (dato1 ,dato2):
  if dato1>=dato2:
    resultado=dato1
  else:
    resultado=dato2
  return resultado

a = int(input("Escriba el primer numero: "))
b = int(input("Escriba el segundo numero: "))
c = MaxNum(a,b)
print("El numero mayores",c)