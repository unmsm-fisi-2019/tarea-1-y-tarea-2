/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package tarea1;

import java.util.Scanner;
/**
 *
 * @author Frank Pomiano Minaya
 */
public class Max2Numeros {
    
    public static void main(String[] args) {
        Scanner entrada = new Scanner(System.in);
        int i = 0 ;
        
        do {
            try {
                i=0;
                System.out.println("Ingrese el primer numero");
                int primerNum = entrada.nextInt();

                System.out.println("Ingrese el segundo numero");
                int segundoNum = entrada.nextInt ();
                if (primerNum >= segundoNum) {
                    System.out.println("El numero mayor es "+ primerNum);
                }
                else {
                    System.out.println("El numero mayor es "+ segundoNum);
                }
            }
            catch (Exception e) {
                System.out.println("Caracter no valido.Escriba de nuevo");
                i=1;
                entrada.nextLine();
            }
        }
        while (i !=0);
        
    

     
        
        
        
    }
     
    
}
