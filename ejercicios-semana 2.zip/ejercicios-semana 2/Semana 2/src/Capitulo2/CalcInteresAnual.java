/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package Capitulo2;

import java.util.Scanner;
/**
 * Ejercicio 13
 * @Frank Pomiano Minaya
 */
public class CalcInteresAnual {
    public static void main(String[] args) {
        Scanner entrada = new Scanner(System.in);
        System.out.println("Ingrese el monto inicial");
        float m = entrada.nextFloat();
        double mfin;
        int i;
        mfin=0;
        for (i=0;i<=5;i++){
            mfin=(mfin+m)*(1+0.00417);
        }
        System.out.println("Al inicio del sexto mes el monto es de"+(float)(mfin));
        
        
    }
}
