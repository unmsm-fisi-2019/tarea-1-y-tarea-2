/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package Capitulo2;

import java.util.Scanner;
/**
 * Ejercicio 23
 * @Frank Pomiano Minaya
 */
public class CostoConducir {
    public static void main(String[] args) {
        Scanner entrada = new Scanner(System.in);
        System.out.println("Ingrese la distancia conducida");
        float dist = entrada.nextFloat();
        System.out.println("Ingrese las millas por galon");
        float mpg = entrada.nextFloat();
        System.out.println("Ingrese el precio del galon");
        float pg = entrada.nextFloat();
        double cpc;
        cpc=(dist/mpg)*pg;
        System.out.println("El cosot por conduccion es "+(float)(cpc));
        
        
    }    
}
