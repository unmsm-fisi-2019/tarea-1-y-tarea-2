/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package Capitulo2;

import java.util.Scanner;
/**
 * Ejercicio 20
 * @Frank Pomiano Minaya
 */
public class CalcInteres {
    public static void main(String[] args) {
        Scanner entrada = new Scanner(System.in);
        System.out.println("Ingrese el balace");
        float bal = entrada.nextFloat();
        System.out.println("Ingrese la tasa de interes");
        float tasa = entrada.nextFloat();
        float inter;
        inter= bal* (tasa/1200);
        System.out.println("El interes  es "+inter);
        
    }
    
}
