/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package Capitulo2;

import java.util.Scanner;
/**
 * Ejercicio 15
 * @Frank Pomiano Minaya
 */
public class DistanciaDosPuntos {
    public static void main(String[] args) {
        Scanner entrada = new Scanner(System.in);
        System.out.println("Ingrese las cordenadas X1 y Y1");
        float x1 = entrada.nextFloat();
        float y1 = entrada.nextFloat();
        System.out.println("Ingrese las cordenadas X2 y Y2");
        float x2 = entrada.nextFloat();
        float y2 = entrada.nextFloat();
        double difx, dify, difqx, difqy, suma, dist;
        difx = (x2-x1);
        dify = (y2-y1);
        difqx = Math.pow(difx,2);
        difqy = Math.pow(dify,2);
        suma=(difqx+difqy);
        dist = Math.pow(suma,0.5);
        System.out.println("La distancia entre dos puntos es "+dist);
        
        
        
        
    }
}
