/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package Capitulo2;

import java.util.Scanner;
/**
 * Ejercicio 7
 * @Frank Pomiano Minaya
 */
public class ConverMinutos {
    public static void main(String[] args) {
        Scanner entrada = new Scanner(System.in);
        System.out.println("Ingrese la cantidad de minutos");
        long min = entrada.nextLong();
        long a, d;
        a=min/525600;
        min=min%525600;
        d=min/1440;
        System.out.print("Abarca "+a);
        System.out.print(" años y "+d);
        System.out.print(" dias");
    }
}
