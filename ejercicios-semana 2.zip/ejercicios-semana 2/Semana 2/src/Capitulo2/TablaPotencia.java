
package Capitulo2;


/**
 * Ejercicio 18
 * @Frank Pomiano Minaya
 */
public class TablaPotencia {
    public static void main(String[] args) {
        System.out.println("a      b      pow(a,b)");
        int a,b,c,i; 
        a=1;
        b=2;
        for (i=1;i<=5;i++) {
            c=(int) Math.pow(a, b);
            System.out.println(a+"      "+b+"      "+c);
            a=a+1;
            b=b+1;     
        }
        
        
        
        
    }
}
