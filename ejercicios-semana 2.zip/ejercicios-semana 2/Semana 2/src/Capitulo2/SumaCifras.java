/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package Capitulo2;

import java.util.Scanner;
/**
 * Ejercicio 6
 * @Frank Pomiano Minaya
 */
public class SumaCifras {
    public static void main(String[] args) {
        Scanner entrada = new Scanner(System.in);
        int num,m = 0,d = 0,c = 0,u = 0,suma;
        do {
            System.out.println("Ingrese un numero entre 0 y 3000");
            num = entrada.nextInt();
        }while (num < 0 && num > 3000);
        m=num/1000;
        num=num%1000;
        c=num/100;
        num=num%100;
        d=num/10;
        num=num%10;
        u=num;
        suma=(m+c+d+u);
        System.out.println("La suma de los digitos del numero es"+suma);
        
        
        
            
    }

   
}
