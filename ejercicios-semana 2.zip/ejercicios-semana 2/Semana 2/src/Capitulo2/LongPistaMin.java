/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package Capitulo2;

import java.util.Scanner;
/**
 * Ejercicio 12
 * @Frank Pomiano Minaya
 */
public class LongPistaMin {
    public static void main(String[] args) {
        Scanner entrada = new Scanner(System.in);
        System.out.println("Ingrese la rapidez del avion");
        float v = entrada.nextFloat();
        System.out.println("Ingrese la aceleracion del avion");
        float a = entrada.nextFloat();
        float lon=(v*v)/(2*a);
        System.out.println("La longitud de pista minima es "+lon);
    }
}
