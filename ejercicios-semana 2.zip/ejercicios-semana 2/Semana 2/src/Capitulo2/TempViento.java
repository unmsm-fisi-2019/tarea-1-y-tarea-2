/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package Capitulo2;

import java.util.Scanner;
/**
 * Ejercicio 17
 * @Frank Pomiano Minaya
 */
public class TempViento {
    public static void main(String[] args) {
        Scanner entrada = new Scanner(System.in);
        double ta, twc, v;
        
        do {
            System.out.println("Ingrese la temperatura Fahrenheit exterior entre -58 y 41");
             ta = entrada.nextFloat();
        }while (ta < -58 && ta > 41);
        do {
            System.out.println("Ingrese la velocidad de1 viento mayor a 2 mph");
            v = entrada.nextFloat();
        }while (ta < 2);
        twc = (35.74)+(0.6215*ta)-(35.75*Math.pow(v, 0.16))+(0.4275*ta*Math.pow(v, 0.16));
        System.out.println("La temperatura del viento es "+twc);
        
    }
    
    
    
    
}
