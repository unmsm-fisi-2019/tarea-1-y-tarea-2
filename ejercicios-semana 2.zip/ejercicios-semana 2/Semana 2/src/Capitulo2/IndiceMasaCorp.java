/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package Capitulo2;

import java.util.Scanner;
/**
 * Ejercicio 14
 * @Frank Pomiano Minaya
 */
public class IndiceMasaCorp {
    public static void main(String[] args) {
        Scanner entrada = new Scanner(System.in);
        System.out.println("Ingrese su peso en libras");
        float lib = entrada.nextFloat();
        System.out.println("Ingrese su altura en pulgadas");
        float pul = entrada.nextFloat();
        double met,kil,imc;
        kil=lib*0.45359237;
        met=pul*0.0254;
        imc=kil/(met*met);
        System.out.println("Su indice de masa corporal es "+(float)(imc));
        
        
        
    }
}
