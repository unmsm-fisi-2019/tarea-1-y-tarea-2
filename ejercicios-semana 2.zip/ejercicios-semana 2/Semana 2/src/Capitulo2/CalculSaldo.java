/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package Capitulo2;

import java.util.Scanner;
/**
 * Ejercicio 5
 * @Frank Pomiano Minaya
 */
public class CalculSaldo {
    public static void main(String[] args) {
        Scanner entrada = new Scanner(System.in);
        System.out.println("Ingrese el subtotal del saldo");
        double subtotal = entrada.nextDouble();
        System.out.println("Ingrese la tasa de gratificacion");
        double tasa = entrada.nextDouble();
        double saldo, gratificacion;
        gratificacion=tasa/100*subtotal;
        saldo=(gratificacion+subtotal);
        
        System.out.println("Su gratificacion es de S/. " +(float)(gratificacion));
        System.out.println("Su saldo es de S/. "+(float)(saldo));
        
    }
}
