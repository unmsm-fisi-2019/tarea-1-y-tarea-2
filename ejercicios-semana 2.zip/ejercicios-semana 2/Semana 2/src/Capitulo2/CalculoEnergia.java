/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package Capitulo2;

import java.util.Scanner;
/**
 * Ejercicio 10
 * @Frank Pomiano Minaya
 */
public class CalculoEnergia {
    public static void main(String[] args) {
        Scanner entrada = new Scanner(System.in);
        System.out.println("Ingrese la cantidad de agua en kilogramos");
        float cant = entrada.nextFloat();
        System.out.println("Ingrese la temperatura inicial");
        float tempin = entrada.nextFloat();
        System.out.println("Ingrese la temperatura inicial");
        float tempfin = entrada.nextFloat();
        float ener;
        ener= (tempfin-tempin)*cant*4184;
        System.out.println("La energia necesaria es "+ener);
        
        
    }
}
