/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package Capitulo2;

import java.util.Scanner;
/**
 * Ejercicio 16
 * @Frank Pomiano Minaya
 */
public class AreaHexagono {
    public static void main(String[] args) {
        Scanner entrada = new Scanner(System.in);
        System.out.println("Ingrese el lado del hexagono");
        float lado = entrada.nextFloat();
        double area;
        area=(3 * Math.pow(3,0.5))/2*(lado*lado);
            System.out.println("El area del hexagono es "+(float)(area));
    }
}
