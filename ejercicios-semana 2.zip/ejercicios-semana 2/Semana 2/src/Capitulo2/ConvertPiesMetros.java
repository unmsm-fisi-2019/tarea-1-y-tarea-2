/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package Capitulo2;

import java.util.Scanner;
/**
 * Ejercicio 3
 * @Frank Pomiano Minaya
 */
public class ConvertPiesMetros {
    public static void main(String[] args) {
        Scanner entrada = new Scanner(System.in);
        System.out.println("Ingrese el valor en pies");
        double pies = entrada.nextDouble();
        double metros;
        metros=pies*0.305;
        System.out.println("El valor en metros es " +(float)(metros));
        
    }
}
