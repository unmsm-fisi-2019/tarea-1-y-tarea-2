/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package Capitulo2;

import java.util.Scanner;
/**
 * Ejercicio 9
 * @Frank Pomiano Minaya
 */
public class Aceleracion {
    public static void main(String[] args) {
        Scanner entrada = new Scanner(System.in);
        System.out.println("Ingrese la rapidez inicial");
        float v0 = entrada.nextFloat();
        System.out.println("Ingrese la rapidez final");
        float v1 = entrada.nextFloat();
        System.out.println("Ingrese el tiempo");
        float t = entrada.nextFloat();
        float a;
        a=(v1-v0)/t;
        System.out.println("La aceleracion es"+a);
    }
}
