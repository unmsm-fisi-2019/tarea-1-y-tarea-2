/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package Capitulo2;

import java.util.Scanner;
/**
 * Ejercicio 2
 * @Frank Pomiano Minaya
 */

public class VolClilindro {
    public static void main(String[] args) {
        Scanner entrada = new Scanner(System.in);
        System.out.println("Ingrese el radio del cilindro");
        double radio = entrada.nextDouble();
        System.out.println("Ingrese la altura del cilindro");
        double alt = entrada.nextDouble();
        double area,volumen;
        area = radio*radio*3.14159;
        volumen = area*alt;
        System.out.println("El area del cilindro es " +(float)(area));
        System.out.println("El area del cilindro es " +(float)(volumen));
    }
}
